﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Spangle_Static
{
    public class Product
    {

        public int p_id { get; set; }
        public string p_Name { get; set; }
        public string p_disc { get; set; }
        public string p_Img { get; set; }
        public int cat_Id { get; set; }
        public string cat_Name { get; set; }
    }
}